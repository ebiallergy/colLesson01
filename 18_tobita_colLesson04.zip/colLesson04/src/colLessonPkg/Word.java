package colLessonPkg;

public class Word{
	public String english;
	public String japanese;
	
	public Word(String _english, String _japanese) {
		this.english = _english;
		this.japanese = _japanese;
	}
	
	public void say() {
		System.out.println("英単語：" + this.english.toString() + "　日本語：" + this.japanese.toString());
	}
}