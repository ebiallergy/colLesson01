package colLessonPkg;
import java.util.Scanner;

public class ColLesson03 {
	public static void main(String[] args) {
		// Wordクラスのインスタンス配列
		Word[] words = new Word[5];

		// コマンドラインから入力
		System.out.println("英単語と日本語をスペースで区切って入力して下さい。");
		Scanner sc  = new Scanner(System.in);
		String input = sc.nextLine();

		// ここから記述してください
		int index = 0;
		int cnt = 0;
		String[] parse;
		
		try {
			while(!input.equals("e")) {
				parse = input.split("　");
				words[index] = new Word(parse[0], parse[1]);
				index++;
				System.out.println("次の単語を入力して下さい。\"e\"で終了します。");
				input = sc.nextLine();
				
				if(index >= 5) {
					System.out.println("登録制限を 越えました。登録済みのデータは以下になります。");
					for(int i=0; i<words.length; i++) {
						if(words[i] != null) {
							words[i].say();	
							cnt++;
						}
					}
					System.out.println(cnt + "件、登録しました。");
					return;
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			System.out.println("登録制限を 越えました。登録済みのデータは以下になります。");
		}
		for(int i=0; i<words.length; i++) {
			if(words[i] != null) {
				words[i].say();	
				cnt++;
			}
		}
		System.out.println(cnt + "件、登録しました。");
	}
}
