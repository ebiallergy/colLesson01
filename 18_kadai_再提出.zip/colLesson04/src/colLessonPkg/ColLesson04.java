package colLessonPkg;
import java.util.Scanner;
import colLessonPkg.Word;
import java.util.ArrayList;

public class ColLesson04 {
	public static void main(String[] args) {
		ArrayList<Word> array = new ArrayList<Word>();

		// コマンドラインから入力
		System.out.println("英単語と日本語をスペースで区切って入力して下さい。");
		Scanner sc  = new Scanner(System.in);
		String input = sc.nextLine();
		
		// ここから記述してください
		int index = 0;
		String[] parse;
		
		try {
			while(!input.equals("e")) {
				parse = input.split("　");
				array.add(new Word(parse[0], parse[1]));
				System.out.println("次の英単語と日本語を入力して下さい。\"e\"で終了します。");
				input = sc.nextLine();
				
				if(array.size() >= 5) {
					ArithmeticException error = new ArithmeticException();
					throw error;
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			System.out.println("登録制限を 越えました。登録済みのデータは以下になります。");
		}
		for(int i=0; i<array.size(); i++) {
			array.get(i).say();
		}
		System.out.println(array.size() + "件、登録しました。");
	}
}
